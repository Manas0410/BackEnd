type TodoData = { id: string; work: string };

export const TODOdata: TodoData[] = [
  { id: "1", work: "work1" },
  { id: "1", work: "work1" },
  { id: "1", work: "work1" },
  { id: "1", work: "work1" },
  { id: "1", work: "work1" },
];
